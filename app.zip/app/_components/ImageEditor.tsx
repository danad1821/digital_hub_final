import { PageDocument } from "../_types/PageData";
import { useRef, useState, useEffect, useMemo } from "react";
import {
  updatePageSectionImage,
  deletePageImageByFileId,
} from "../_actions/pages";
import { X, Loader2, Upload, Trash2 } from "lucide-react";
import Image from "next/image";

interface ImageEditorProps {
  sectionIndex: number;
  imageKey: string; // e.g., 'image_ref'
  pageData: PageDocument;
  sectionData: any;
  setPageData: React.Dispatch<React.SetStateAction<PageDocument | null>>;
  isLarge?: boolean; // For visual styling
  slug: string;
}

const ImageEditor: React.FC<ImageEditorProps> = ({
  sectionIndex,
  imageKey,
  sectionData,
  pageData,
  setPageData,
  isLarge = false,
  slug,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  if (!pageData || !pageData.sections || !pageData.sections[sectionIndex]) {
    return null;
  }

  const currentFileId = sectionData.data[imageKey] || null;

  // Clear temporary object URL when component unmounts or file changes
  useEffect(() => {
    return () => {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Create a client-side preview URL for immediate display
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
      setPreviewUrl(URL.createObjectURL(file));
    } else {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
      setPreviewUrl(null);
    }
  };

  const handleUpload = async (sectionType: string) => {
    if (!fileInputRef.current?.files?.[0]) {
      alert("Please select a file first.");
      return;
    }
    console.log("Initiating upload for section type:", sectionType);
    const file = fileInputRef.current.files[0];

    // We removed the manual 'deletePageImageByFileId' call because
    // updatePageSectionImage handles old file cleanup on the server.

    setIsUploading(true);
    const formData = new FormData();
    formData.append("image", file); // 'image' must match the key expected by uploadImage

    try {
      // 🌟 KEY FIX: Call the single, atomic Server Action
      // This function uploads the file, updates the 'image_ref' in MongoDB,
      // AND deletes the old GridFS file.
      const result = await updatePageSectionImage(slug, sectionType, formData);

      if (result.success && result.newImageUrl) {
        setPageData((prevData: any) => {
          if (!prevData) return null;

          // 1. Ensure sections is an array before using array methods
          let currentSections = [];
          try {
            currentSections =
              typeof prevData.sections === "string"
                ? JSON.parse(prevData.sections)
                : prevData.sections;
          } catch (e) {
            console.error("Failed to parse sections in ImageEditor:", e);
            return prevData;
          }

          // 2. Now findIndex will work
          const sectionIndex = currentSections.findIndex(
            (s: any) => s.type === sectionType,
          );

          if (sectionIndex === -1) return prevData;

          const newSections = [...currentSections];
          const imageKey = "image_ref";

          newSections[sectionIndex] = {
            ...newSections[sectionIndex],
            data: {
              ...(newSections[sectionIndex].data || {}), // Guard against missing data object
              [imageKey]: result.newImageUrl,
            },
          };

          // 3. Save it back.
          // If your parent component expects a string, stringify it here.
          return {
            ...prevData,
            sections:
              typeof prevData.sections === "string"
                ? JSON.stringify(newSections)
                : newSections,
          };
        });

        // Clear input and preview after successful upload
        if (fileInputRef.current) fileInputRef.current.value = "";
        if (previewUrl) URL.revokeObjectURL(previewUrl);
        setPreviewUrl(null);
      } else {
        // Check for explicit error message from server action
        throw new Error(
          result.error || "Database update failed or returned no file ID.",
        );
      }
    } catch (error) {
      alert(`Upload error: ${(error as Error).message}`);
    } finally {
      setIsUploading(false);
    }
  };

  const handleDelete = async () => {
    if (!currentFileId || currentFileId.startsWith("/images/")) {
      // Cannot delete if no ID or if it's a static path placeholder
      return;
    }

    if (!window.confirm("Are you sure you want to remove this image?")) {
      return;
    }

    setIsUploading(true); // Reusing upload state for deletion status

    try {
      const result = await deletePageImageByFileId(slug, sectionIndex);

      if (result.success) {
        // Remove the image reference from pageData state
        setPageData((prevData: any) => {
          if (!prevData) return null;
          const newSections = [...prevData.sections];
          newSections[sectionIndex] = {
            ...newSections[sectionIndex],
            data: { ...newSections[sectionIndex].data, [imageKey]: "" },
          };
          return { ...prevData, sections: newSections };
        });
      } else {
        throw new Error(result.error || "Deletion failed on the server.");
      }
    } catch (error) {
      alert(`Deletion error: ${(error as Error).message}`);
    } finally {
      setIsUploading(false);
    }
  };


  const imgSrc = useMemo(() => {
    if (previewUrl) {
      return previewUrl;
    }

    if (currentFileId) {
      // 🌟 FIX: If currentFileId is already a full URL or a relative path, use it directly
      if (currentFileId.startsWith("http") || currentFileId.startsWith("/")) {
        return currentFileId;
      }
      // Otherwise, assume it is a GridFS ID and use the API route
      return `/api/files/${currentFileId}`;
    }

    return null;
  }, [currentFileId, previewUrl]);

  // Check if the current reference is a valid uploaded image (i.e., a GridFS ID)
  const hasUploadedImage =
    currentFileId && !currentFileId.startsWith("/images/");

  return (
    <div
      className={` ${isLarge ? "p-0" : "p-4"} z-10 flex flex-col justify-end items-center max-h-[400px] overflow-hidden rounded-lg`}
    >
      {/* Visual Preview */}
      {imgSrc && (
        <img
          src={imgSrc}
          alt="Current or uploaded image preview"
          sizes="50vw"
          className={`object-cover ${isLarge ? "opacity-50" : "opacity-20"} w-100 h-100`}
        />
      )}

      <div
        className={`p-4 rounded-lg bg-black/80 text-white shadow-xl flex gap-3 items-center z-20 ${isLarge ? "mb-4" : ""}`}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/*"
          className="hidden"
          id={`file-upload-${sectionIndex}-${imageKey}`}
          disabled={isUploading}
        />

        <label
          htmlFor={`file-upload-${sectionIndex}-${imageKey}`}
          className={`flex items-center justify-center p-2 rounded-md transition-colors cursor-pointer 
                        ${isUploading ? "bg-gray-600" : "bg-blue-600 hover:bg-blue-700"}`}
        >
          <Upload className="w-5 h-5 mr-2" />
          {hasUploadedImage ? "Change Image" : "Select Image"}
        </label>

        {previewUrl && (
          <button
            type="button"
            onClick={() => handleUpload(sectionData.type)}
            disabled={isUploading}
            className={`flex items-center justify-center p-2 rounded-md transition-colors text-white ${isUploading ? "bg-gray-500" : "bg-green-600 hover:bg-green-700"}`}
          >
            {isUploading ? (
              <Loader2 className="animate-spin w-5 h-5" />
            ) : (
              <Upload className="w-5 h-5" />
            )}
            {isUploading ? "Uploading..." : "Confirm Upload"}
          </button>
        )}

        {hasUploadedImage && !previewUrl && (
          <button
            type="button"
            onClick={handleDelete}
            disabled={isUploading}
            className={`flex items-center justify-center p-2 rounded-md transition-colors text-white ${isUploading ? "bg-gray-500" : "bg-red-600 hover:bg-red-700"}`}
          >
            {isUploading ? (
              <Loader2 className="animate-spin w-5 h-5" />
            ) : (
              <Trash2 className="w-5 h-5" />
            )}
            Remove
          </button>
        )}

        {previewUrl && (
          <button
            type="button"
            onClick={() => {
              if (fileInputRef.current) fileInputRef.current.value = "";
              if (previewUrl) URL.revokeObjectURL(previewUrl);
              setPreviewUrl(null);
            }}
            className="p-2 rounded-md bg-yellow-500 hover:bg-yellow-600"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Display current ID for reference */}
        <span className="text-xs text-gray-400 max-w-[150px] truncate ml-3">
          ID: {hasUploadedImage ? currentFileId : "Static/None"}
        </span>
      </div>
    </div>
  );
};

export default ImageEditor;
